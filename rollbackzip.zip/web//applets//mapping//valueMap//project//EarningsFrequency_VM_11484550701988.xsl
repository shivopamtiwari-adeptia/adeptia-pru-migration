<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.1" xmlns:java="http://xml.apache.org/xslt/java" xmlns:xalan="http://xml.apache.org/xalan" xmlns:str="http://exslt.org/strings" xmlns:redirect="org.apache.xalan.xslt.extensions.Redirect" extension-element-prefixes="redirect" >
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" />
<xsl:param name="_userName"/>
<xsl:param name="_password"/>
<xsl:param name="_class"/>
<xsl:param name="_identifier"/>
<xsl:param name="_subject"/>
<xsl:param name="_repositoryPath"/>
<xsl:param name="_Input1"/>
<xsl:variable name="varConn" select="java:com.adeptia.indigo.services.mapping.support.dbquery.MapperQueryExecutor.getInstance($_identifier,'false')"/>
<xsl:variable name="apos">'</xsl:variable><xsl:template name="EarningsFrequency_VM">
	<xsl:param name="param"/>
<xsl:choose><xsl:when test="$param=&apos;ANNUAL&apos;"><xsl:value-of select="&apos;ANNUAL&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;BIMNTHLY&apos;"><xsl:value-of select="&apos;BIMNTHLY&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;BIWKLY&apos;"><xsl:value-of select="&apos;BIWKLY&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;DAILY&apos;"><xsl:value-of select="&apos;DAILY&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;HOURLY&apos;"><xsl:value-of select="&apos;HOURLY&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;MNTHLY&apos;"><xsl:value-of select="&apos;MNTHLY&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;NONE&apos;"><xsl:value-of select="&apos;NONE&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;QUARTLY&apos;"><xsl:value-of select="&apos;QUARTLY&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;WKLY&apos;"><xsl:value-of select="&apos;WKLY&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;OTHER&apos;"><xsl:value-of select="&apos;OTHER&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;UNKNOWN&apos;"><xsl:value-of select="&apos;UNKNOWN&apos;"/></xsl:when><xsl:otherwise><xsl:value-of select="&apos;&apos;"/></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:template>

</xsl:stylesheet>
