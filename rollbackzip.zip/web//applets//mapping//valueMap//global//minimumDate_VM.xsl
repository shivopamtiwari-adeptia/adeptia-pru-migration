<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.1" xmlns:java="http://xml.apache.org/xslt/java" xmlns:xalan="http://xml.apache.org/xalan" xmlns:str="http://exslt.org/strings" xmlns:redirect="org.apache.xalan.xslt.extensions.Redirect" extension-element-prefixes="redirect" >
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" />
<xsl:param name="_userName"/>
<xsl:param name="_password"/>
<xsl:param name="_class"/>
<xsl:param name="_identifier"/>
<xsl:param name="_subject"/>
<xsl:param name="_repositoryPath"/>
<xsl:param name="_Input1"/>
<xsl:variable name="varConn" select="java:com.adeptia.indigo.services.mapping.support.dbquery.MapperQueryExecutor.getInstance($_identifier,'false')"/>
<xsl:variable name="apos">'</xsl:variable><xsl:template name="minimumDate_VM">
	<xsl:param name="param"/>
<xsl:choose><xsl:when test="$param=&apos;60442&apos;"><xsl:value-of select="&apos;03/01/2026&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;71771&apos;"><xsl:value-of select="&apos;01/01/2026&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;72457&apos;"><xsl:value-of select="&apos;05/01/2026&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;49790&apos;"><xsl:value-of select="&apos;04/01/2026&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;72363&apos;"><xsl:value-of select="&apos;04/01/2026&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;71184&apos;"><xsl:value-of select="&apos;04/01/2026&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;71211&apos;"><xsl:value-of select="&apos;04/01/2026&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;72090&apos;"><xsl:value-of select="&apos;04/01/2026&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;72303&apos;"><xsl:value-of select="&apos;04/01/2026&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;71426&apos;"><xsl:value-of select="&apos;04/01/2026&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;72396&apos;"><xsl:value-of select="&apos;04/01/2026&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;73095&apos;"><xsl:value-of select="&apos;04/01/2026&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;72135&apos;"><xsl:value-of select="&apos;04/01/2026&apos;"/></xsl:when><xsl:otherwise><xsl:value-of select="&apos;04/01/2026&apos;"/></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:template>

</xsl:stylesheet>
