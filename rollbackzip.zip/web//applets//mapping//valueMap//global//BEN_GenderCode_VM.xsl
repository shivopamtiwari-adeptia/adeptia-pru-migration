<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.1" xmlns:java="http://xml.apache.org/xslt/java" xmlns:xalan="http://xml.apache.org/xalan" xmlns:str="http://exslt.org/strings" xmlns:redirect="org.apache.xalan.xslt.extensions.Redirect" extension-element-prefixes="redirect" >
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" />
<xsl:param name="_userName"/>
<xsl:param name="_password"/>
<xsl:param name="_class"/>
<xsl:param name="_identifier"/>
<xsl:param name="_subject"/>
<xsl:param name="_repositoryPath"/>
<xsl:param name="_Input1"/>
<xsl:variable name="varConn" select="java:com.adeptia.indigo.services.mapping.support.dbquery.MapperQueryExecutor.getInstance($_identifier,'false')"/>
<xsl:variable name="apos">'</xsl:variable><xsl:template name="BEN_GenderCode_VM">
	<xsl:param name="param"/>
<xsl:choose><xsl:when test="$param=&apos;MALE&apos;"><xsl:value-of select="&apos;MALE&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;FEMALE&apos;"><xsl:value-of select="&apos;FEMALE&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;NONBINARY&apos;"><xsl:value-of select="&apos;NONBINARY&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;M&apos;"><xsl:value-of select="&apos;MALE&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;F&apos;"><xsl:value-of select="&apos;FEMALE&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;UNISEX&apos;"><xsl:value-of select="&apos;UNISEX&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;OTHER&apos;"><xsl:value-of select="&apos;OTHER&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;UNKNOWN&apos;"><xsl:value-of select="&apos;UNKNOWN&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;NON BINARY&apos;"><xsl:value-of select="&apos;NONBINARY&apos;"/></xsl:when><xsl:otherwise><xsl:value-of select="&apos;UNKNOWN&apos;"/></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:template>

</xsl:stylesheet>
