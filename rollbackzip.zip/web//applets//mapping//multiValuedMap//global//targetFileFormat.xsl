<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.1" xmlns:java="http://xml.apache.org/xslt/java" xmlns:xalan="http://xml.apache.org/xalan" xmlns:str="http://exslt.org/strings" xmlns:redirect="org.apache.xalan.xslt.extensions.Redirect" extension-element-prefixes="redirect" >
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" />
<xsl:param name="_userName"/>
<xsl:param name="_password"/>
<xsl:param name="_class"/>
<xsl:param name="_identifier"/>
<xsl:param name="_subject"/>
<xsl:param name="_repositoryPath"/>
<xsl:param name="_Input1"/>
<xsl:variable name="varConn" select="java:com.adeptia.indigo.services.mapping.support.dbquery.MapperQueryExecutor.getInstance($_identifier,'false')"/>
<xsl:variable name="apos">'</xsl:variable><xsl:template name="targetFileFormat"><xsl:param name="sourceValue"/><xsl:param name="mapValueDisplayName"/><xsl:variable name="multiValuedMapDocument" select="document('targetFileFormat.xml')"/><xsl:variable name="mapValueFieldName" select="$multiValuedMapDocument/MultiValuedMapDetails/MapValueFieldNames/MapValueFieldName[DisplayName = $mapValueDisplayName]/FieldName"/><xsl:variable name="defaultValue" select="$multiValuedMapDocument/MultiValuedMapDetails/MapValueFieldNames/MapValueFieldName[DisplayName = $mapValueDisplayName]/DefaultValue/Value"/><xsl:variable name="pickFromSource" select="$multiValuedMapDocument/MultiValuedMapDetails/MapValueFieldNames/MapValueFieldName[DisplayName = $mapValueDisplayName]/DefaultValue/PickFromSource"/><xsl:variable name="mapValue" select="$multiValuedMapDocument/MultiValuedMapDetails/MultiValuedMaps/MultiValuedMap[Value = $sourceValue]/*[local-name()= $mapValueFieldName]"/><xsl:choose><xsl:when test="$mapValue!=''"><xsl:value-of select="$mapValue"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$pickFromSource='true'"><xsl:value-of select="$sourceValue"/></xsl:when><xsl:otherwise><xsl:value-of select="$defaultValue"/></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:template>

</xsl:stylesheet>
