<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.1" xmlns:java="http://xml.apache.org/xslt/java" xmlns:xalan="http://xml.apache.org/xalan" xmlns:str="http://exslt.org/strings" xmlns:redirect="org.apache.xalan.xslt.extensions.Redirect" extension-element-prefixes="redirect" >
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" />
<xsl:param name="_userName"/>
<xsl:param name="_password"/>
<xsl:param name="_class"/>
<xsl:param name="_identifier"/>
<xsl:param name="_subject"/>
<xsl:param name="_repositoryPath"/>
<xsl:param name="_Input1"/>
<xsl:variable name="varConn" select="java:com.adeptia.indigo.services.mapping.support.dbquery.MapperQueryExecutor.getInstance($_identifier,'false')"/>
<xsl:variable name="apos">'</xsl:variable><xsl:template name="STD_CoverageBuyUpEndDate_VM">
	<xsl:param name="param"/>
<xsl:choose><xsl:when test="$param=&apos;72791&apos;"><xsl:value-of select="&apos;DOH&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;12345&apos;"><xsl:value-of select="&apos;DOH30&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;51791&apos;"><xsl:value-of select="&apos;DOH60&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;52136&apos;"><xsl:value-of select="&apos;FOMDOH&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;51936&apos;"><xsl:value-of select="&apos;FOMDOH30&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;43251&apos;"><xsl:value-of select="&apos;FOMDOH60&apos;"/></xsl:when><xsl:otherwise><xsl:value-of select="&apos;&apos;"/></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:template>

</xsl:stylesheet>
