<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.1" xmlns:java="http://xml.apache.org/xslt/java" xmlns:xalan="http://xml.apache.org/xalan" xmlns:str="http://exslt.org/strings" xmlns:redirect="org.apache.xalan.xslt.extensions.Redirect" extension-element-prefixes="redirect" >
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" />
<xsl:param name="_userName"/>
<xsl:param name="_password"/>
<xsl:param name="_class"/>
<xsl:param name="_identifier"/>
<xsl:param name="_subject"/>
<xsl:param name="_repositoryPath"/>
<xsl:param name="_Input1"/>
<xsl:variable name="varConn" select="java:com.adeptia.indigo.services.mapping.support.dbquery.MapperQueryExecutor.getInstance($_identifier,'false')"/>
<xsl:variable name="apos">'</xsl:variable><xsl:template name="W4FilingStatus_VM">
	<xsl:param name="param"/>
<xsl:choose><xsl:when test="$param=&apos;W4001&apos;"><xsl:value-of select="&apos;SINGLE&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;W4002&apos;"><xsl:value-of select="&apos;HEAD OF HOUSEHOLD&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;W4003&apos;"><xsl:value-of select="&apos;MARRIED&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;W4004&apos;"><xsl:value-of select="&apos;EXEMPT&apos;"/></xsl:when><xsl:otherwise><xsl:value-of select="&apos;&apos;"/></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:template>

</xsl:stylesheet>
