<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.1" xmlns:java="http://xml.apache.org/xslt/java" xmlns:xalan="http://xml.apache.org/xalan" xmlns:str="http://exslt.org/strings" xmlns:redirect="org.apache.xalan.xslt.extensions.Redirect" extension-element-prefixes="redirect" >
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" />
<xsl:param name="_userName"/>
<xsl:param name="_password"/>
<xsl:param name="_class"/>
<xsl:param name="_identifier"/>
<xsl:param name="_subject"/>
<xsl:param name="_repositoryPath"/>
<xsl:param name="_Input1"/>
<xsl:variable name="varConn" select="java:com.adeptia.indigo.services.mapping.support.dbquery.MapperQueryExecutor.getInstance($_identifier,'false')"/>
<xsl:variable name="apos">'</xsl:variable><xsl:template name="Salary_Frequency_VM">
	<xsl:param name="param"/>
<xsl:choose><xsl:when test="$param=&apos;13001&apos;"><xsl:value-of select="&apos;Hourly (40 hr. week)&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;13002&apos;"><xsl:value-of select="&apos;Hourly (37.5 hr. week)&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;13003&apos;"><xsl:value-of select="&apos;Weekly&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;13004&apos;"><xsl:value-of select="&apos;Bi-Weekly&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;13005&apos;"><xsl:value-of select="&apos;Monthly&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;13006&apos;"><xsl:value-of select="&apos;Annually&apos;"/></xsl:when><xsl:otherwise><xsl:choose><xsl:when test="$param=&apos;13008&apos;"><xsl:value-of select="&apos;Semi-Monthly&apos;"/></xsl:when><xsl:otherwise><xsl:value-of select="&apos;&apos;"/></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:otherwise></xsl:choose></xsl:template>

</xsl:stylesheet>
